/**
 * Seed script: Create sample quotes with line items for PDF download testing
 */
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

const GST_RATE = 18
const FX_RATE = 84.5

async function main() {
  const tenant = await db.tenant.findFirst({ where: { slug: 'isecurify' } })
  if (!tenant) throw new Error('Tenant not found')

  const clients = await db.client.findMany({ where: { tenantId: tenant.id } })
  const frameworks = await db.framework.findMany({ where: { isActive: true } })
  const tiers = await db.tier.findMany()
  const users = await db.user.findMany({ where: { tenantId: tenant.id } })
  const prices = await db.frameworkPrice.findMany({
    where: { tenantId: tenant.id },
    include: { framework: true, tier: true },
  })
  const auditorFees = await db.auditorFee.findMany({ where: { tenantId: tenant.id, isActive: true } })
  const addons = await db.addonService.findMany({ where: { tenantId: tenant.id, isActive: true } })
  const grcTools = await db.grcTool.findMany({ where: { tenantId: tenant.id, isActive: true } })
  const dpoPackages = await db.dpoVcisoPackage.findMany({ where: { tenantId: tenant.id, isActive: true } })

  const admin = users.find(u => u.role === 'super_admin') || users[0]
  const manager = users.find(u => u.role === 'sales_manager') || users[1]
  const finance = users.find(u => u.role === 'finance') || users[2]

  // Quote definitions
  const quoteDefs = [
    {
      clientIdx: 0, fwName: 'ISO 27001', tierName: 'Enterprise', discountPct: 5,
      status: 'APPROVED', approvedByIdx: 1, includeRetainer: true,
      addAuditor: true, addGrcTool: true, addDpo: false,
      notes: 'Includes gap analysis and 3-day on-site audit. Discount applied for multi-year engagement commitment.',
      daysAgo: 2,
    },
    {
      clientIdx: 1, fwName: 'SOC 2 Type 2', tierName: 'Mid-size', discountPct: 10,
      status: 'DRAFT', approvedByIdx: -1, includeRetainer: false,
      addAuditor: true, addGrcTool: false, addDpo: true,
      notes: 'Fintech client — enhanced scoping for trust service criteria.',
      daysAgo: 5,
    },
    {
      clientIdx: 2, fwName: 'HIPAA', tierName: 'Enterprise', discountPct: 0,
      status: 'PENDING_REVIEW', approvedByIdx: -1, includeRetainer: true,
      addAuditor: true, addGrcTool: true, addDpo: true,
      notes: 'Healthcare client — PHI handling scope assessment needed.',
      daysAgo: 7,
    },
    {
      clientIdx: 4, fwName: 'ISO 22301', tierName: 'Mid-size', discountPct: 8,
      status: 'SENT', approvedByIdx: 1, includeRetainer: false,
      addAuditor: true, addGrcTool: false, addDpo: false,
      notes: '',
      daysAgo: 14,
    },
    {
      clientIdx: 5, fwName: 'ISO 42001', tierName: 'Startup', discountPct: 15,
      status: 'DRAFT', approvedByIdx: -1, includeRetainer: false,
      addAuditor: false, addGrcTool: true, addDpo: false,
      notes: 'AI startup — first compliance engagement.',
      daysAgo: 1,
    },
  ]

  for (const def of quoteDefs) {
    const client = clients[def.clientIdx]
    const fw = frameworks.find(f => f.name === def.fwName)
    const tier = tiers.find(t => t.name === def.tierName)
    if (!client || !fw || !tier) {
      console.log(`Skipping: missing data for ${def.fwName}/${def.tierName}`)
      continue
    }

    const price = prices.find(p => p.frameworkId === fw.id && p.tierId === tier.id)
    const auditorFee = def.addAuditor ? auditorFees.find(a => a.frameworkId === fw.id) : null
    const addon1 = addons[0]
    const addon2 = addons[1]
    const grcTool = def.addGrcTool ? grcTools[0] : null
    const dpo = def.addDpo ? dpoPackages[0] : null

    const projectFee = price?.projectFeeInr ?? 300000
    const retainerFee = price?.retainerFeeInr ?? 50000
    const auditorAmount = auditorFee?.feeInr ?? 150000
    const addon1Amt = addon1?.priceInr ?? 75000
    const addon2Amt = addon2?.priceInr ?? 50000
    const grcAmt = grcTool?.annualPriceInr ?? 120000
    const dpoAmt = dpo?.annualPriceInr ?? 600000

    // Calculate totals
    let subtotal = projectFee
    if (def.includeRetainer) subtotal += retainerFee
    if (auditorAmount) subtotal += auditorAmount
    if (addon1) subtotal += addon1Amt
    if (addon2) subtotal += addon2Amt
    if (grcTool) subtotal += grcAmt
    if (dpo) subtotal += dpoAmt

    const discountAmt = subtotal * (def.discountPct / 100)
    const afterDiscount = subtotal - discountAmt
    const gst = afterDiscount * (GST_RATE / 100)
    const total = afterDiscount + gst
    const totalUsd = total / FX_RATE
    const retainerAmt = def.includeRetainer ? retainerFee : 0

    const createdAt = new Date()
    createdAt.setDate(createdAt.getDate() - def.daysAgo)

    const validUntil = new Date(createdAt)
    validUntil.setDate(validUntil.getDate() + 30)

    const approvedBy = def.approvedByIdx >= 0 ? users[def.approvedByIdx] : null

    const quote = await db.quote.create({
      data: {
        tenantId: tenant.id,
        clientId: client.id,
        version: 1,
        status: def.status,
        frameworkId: fw.id,
        tierId: tier.id,
        subtotalInr: subtotal,
        discountInr: discountAmt,
        discountPct: def.discountPct,
        gstAmountInr: gst,
        totalInr: total,
        totalUsd: totalUsd,
        usdInrRateSnapshot: FX_RATE,
        gstRateSnapshot: GST_RATE,
        includeRetainer: def.includeRetainer,
        retainerAmountInr: retainerAmt,
        internalHours: 40,
        internalHourlyRate: 3500,
        validUntil,
        notes: def.notes || null,
        createdById: admin.id,
        approvedById: approvedBy?.id || null,
        createdAt,
        lineItems: {
          create: [
            { lineType: 'consulting_fee', description: `${fw.name} — ${tier.name} Tier Project Fee`, amountInr: projectFee, sortOrder: 1 },
            ...(def.includeRetainer ? [{ lineType: 'retainer' as const, description: `${fw.name} — Annual Retainer`, amountInr: retainerFee, sortOrder: 2 }] : []),
            ...(auditorAmount ? [{ lineType: 'auditor_fee' as const, description: `Lead Auditor Fee — ${fw.name}`, amountInr: auditorAmount, sortOrder: 3 }] : []),
            ...(addon1 ? [{ lineType: 'addon_service' as const, description: `${addon1.name}`, amountInr: addon1Amt, sortOrder: 4 }] : []),
            ...(addon2 ? [{ lineType: 'addon_service' as const, description: `${addon2.name}`, amountInr: addon2Amt, sortOrder: 5 }] : []),
            ...(grcTool ? [{ lineType: 'grc_tool' as const, description: `${grcTool.name} — Annual License`, amountInr: grcAmt, sortOrder: 6 }] : []),
            ...(dpo ? [{ lineType: 'dpo_vciso' as const, description: `${dpo.name}`, amountInr: dpoAmt, sortOrder: 7 }] : []),
            { lineType: 'internal_time', description: 'Internal Advisory Time (40 hrs × ₹3,500)', amountInr: 140000, sortOrder: 99 },
          ],
        },
        ...(def.status !== 'DRAFT' ? {
          approvals: {
            create: {
              actorId: admin.id,
              actorRole: admin.role,
              action: 'submitted',
              comment: 'Quote submitted for review',
              createdAt,
            },
          },
        } : {}),
      },
    })

    // Add approval for APPROVED quotes
    if (def.status === 'APPROVED' && approvedBy) {
      const approvedAt = new Date(createdAt)
      approvedAt.setDate(approvedAt.getDate() + 1)
      await db.quoteApproval.create({
        data: {
          quoteId: quote.id,
          actorId: approvedBy.id,
          actorRole: approvedBy.role,
          action: 'approved',
          comment: 'Approved — pricing looks competitive',
          createdAt: approvedAt,
        },
      })
    }

    if (def.status === 'PENDING_REVIEW') {
      await db.quoteApproval.create({
        data: {
          quoteId: quote.id,
          actorId: admin.id,
          actorRole: admin.role,
          action: 'submitted',
          comment: 'Submitted for management review',
          createdAt: new Date(createdAt.getTime() + 3600000),
        },
      })
    }

    if (def.status === 'SENT') {
      const sentAt = new Date(createdAt)
      sentAt.setDate(sentAt.getDate() + 3)
      await db.quote.update({
        where: { id: quote.id },
        data: {
          sentAt,
        },
      })
      await db.quoteApproval.createMany({
        data: [
          { quoteId: quote.id, actorId: admin.id, actorRole: admin.role, action: 'submitted', comment: 'Initial submission', createdAt: new Date(createdAt.getTime() + 3600000) },
          { quoteId: quote.id, actorId: approvedBy!.id, actorRole: approvedBy!.role, action: 'approved', comment: 'Approved', createdAt: new Date(sentAt.getTime() - 86400000) },
          { quoteId: quote.id, actorId: approvedBy!.id, actorRole: approvedBy!.role, action: 'sent', comment: 'Sent to client via email', createdAt: sentAt },
        ],
      })
    }

    console.log(`✓ Quote: ${fw.name} / ${client.companyName} — ₹${Math.round(total).toLocaleString('en-IN')} [${def.status}]`)
  }

  console.log(`\nSeeded ${quoteDefs.length} quotes successfully.`)
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())