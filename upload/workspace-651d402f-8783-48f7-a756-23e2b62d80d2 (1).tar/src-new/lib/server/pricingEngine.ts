/**
 * iSecurify — Server-side quote calculation helper
 * Used by API routes to (re)compute quote totals before persisting.
 */
import { db } from '@/lib/db'
import type { QuoteBuilderSelection } from '@/types'

export interface ComputedQuote {
  lines: Array<{
    lineType: string
    description: string
    referenceId?: string | null
    amountInr: number
    sortOrder: number
  }>
  subtotalInr: number
  discountInr: number
  gstAmountInr: number
  totalInr: number
  totalUsd: number
  retainerAmountInr: number
  internalHours: number
  internalHourlyRate: number
  frameworkId: string
  tierId: string
  includeRetainer: boolean
  usdInrRateSnapshot: number
  gstRateSnapshot: number
}

const GST_RATE = 18
const TENANT_ID = 'tenant-isecurify'
const CREATED_BY_ID = 'user-admin'

export async function computeQuote(
  selection: QuoteBuilderSelection,
): Promise<ComputedQuote | null> {
  if (!selection.frameworkId || !selection.tierId) return null

  const [framework, tier, price, fxRateRow] = await Promise.all([
    db.framework.findUnique({ where: { id: selection.frameworkId } }),
    db.tier.findUnique({ where: { id: selection.tierId } }),
    db.frameworkPrice.findFirst({
      where: {
        frameworkId: selection.frameworkId,
        tierId: selection.tierId,
        OR: [{ tenantId: null }, { tenantId: TENANT_ID }],
      },
      orderBy: { tenantId: 'desc' }, // tenant-specific first
    }),
    db.fxRate.findFirst(),
  ])

  if (!framework || !tier || !price) return null

  const usdInrRate = fxRateRow?.rate ?? 83
  const lines: ComputedQuote['lines'] = []
  let sortOrder = 0
  let subtotal = 0
  let retainerAmount = 0

  // 1. Consulting fee
  lines.push({
    lineType: 'consulting_fee',
    description: `${framework.name} — Consulting Fee (${tier.name})`,
    referenceId: framework.id,
    amountInr: price.projectFeeInr,
    sortOrder: sortOrder++,
  })
  subtotal += price.projectFeeInr

  if (selection.includeRetainer && price.retainerFeeInr > 0) {
    retainerAmount = price.retainerFeeInr
    lines.push({
      lineType: 'retainer',
      description: `Annual Retainer (${tier.retainerPct}% of project fee)`,
      referenceId: tier.id,
      amountInr: price.retainerFeeInr,
      sortOrder: sortOrder++,
    })
    subtotal += price.retainerFeeInr
  }

  // 2. Auditor fees
  if (selection.selectedAuditorFeeIds.length > 0) {
    const fees = await db.auditorFee.findMany({
      where: { id: { in: selection.selectedAuditorFeeIds } },
    })
    for (const fee of fees) {
      lines.push({
        lineType: 'auditor_fee',
        description: `Auditor Fee — ${fee.standardName} (${fee.accreditationBody})`,
        referenceId: fee.id,
        amountInr: fee.feeInr,
        sortOrder: sortOrder++,
      })
      subtotal += fee.feeInr
    }
  }

  // 3. Add-on services
  if (selection.selectedAddonIds.length > 0) {
    const addons = await db.addonService.findMany({
      where: { id: { in: selection.selectedAddonIds } },
    })
    for (const addon of addons) {
      lines.push({
        lineType: 'addon_service',
        description: addon.name,
        referenceId: addon.id,
        amountInr: addon.feeInr,
        sortOrder: sortOrder++,
      })
      subtotal += addon.feeInr
    }
  }

  // 4. GRC Tool
  if (selection.grcToolEnabled) {
    let fee = 0
    let label = 'GRC Tool'
    if (selection.grcToolCustomFee !== null && selection.grcToolCustomFee > 0) {
      fee = selection.grcToolCustomFee
      label = 'GRC Tool (Custom)'
    } else if (selection.grcToolId) {
      const tool = await db.grcTool.findUnique({ where: { id: selection.grcToolId } })
      if (tool) {
        fee = tool.feeInrAnnual
        label = `GRC Tool — ${tool.planName} (Annual)`
      }
    }
    if (fee > 0) {
      lines.push({
        lineType: 'grc_tool',
        description: label,
        referenceId: selection.grcToolId,
        amountInr: fee,
        sortOrder: sortOrder++,
      })
      subtotal += fee
    }
  }

  // 5. DPO/vCISO package
  if (selection.dpoVcisoPackageId) {
    const pkg = await db.dpoVcisoPackage.findUnique({
      where: { id: selection.dpoVcisoPackageId },
    })
    if (pkg) {
      lines.push({
        lineType: 'dpo_vciso',
        description: `${pkg.serviceType} — ${pkg.name} (Annual)`,
        referenceId: pkg.id,
        amountInr: pkg.feeInrAnnual,
        sortOrder: sortOrder++,
      })
      subtotal += pkg.feeInrAnnual
    }
  }

  // 6. Discount
  const discount = Math.max(0, selection.discountInr || 0)
  if (discount > 0) {
    lines.push({
      lineType: 'discount',
      description: `Discount${selection.discountReason ? ` — ${selection.discountReason}` : ''}`,
      amountInr: -discount,
      sortOrder: sortOrder++,
    })
  }

  // 7. Internal time (advisory — NOT billed)
  const internalTimeCost = selection.internalHours * selection.internalHourlyRate
  if (internalTimeCost > 0) {
    lines.push({
      lineType: 'internal_time',
      description: `Internal time cost (advisory – not billed) — ${selection.internalHours}h × ₹${selection.internalHourlyRate}/hr`,
      amountInr: internalTimeCost,
      sortOrder: sortOrder++,
    })
  }

  const subtotalAfterDiscount = Math.max(0, subtotal - discount)
  const gstAmount = Math.round(subtotalAfterDiscount * (GST_RATE / 100))
  const total = subtotalAfterDiscount + gstAmount
  const totalUsd = Math.round((total / usdInrRate) * 100) / 100

  return {
    lines,
    subtotalInr: subtotal,
    discountInr: discount,
    gstAmountInr: gstAmount,
    totalInr: total,
    totalUsd,
    retainerAmountInr: retainerAmount,
    internalHours: selection.internalHours,
    internalHourlyRate: selection.internalHourlyRate,
    frameworkId: framework.id,
    tierId: tier.id,
    includeRetainer: selection.includeRetainer,
    usdInrRateSnapshot: usdInrRate,
    gstRateSnapshot: GST_RATE,
  }
}

export { TENANT_ID, CREATED_BY_ID, GST_RATE }
