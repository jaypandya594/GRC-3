/**
 * iSecurify — Dashboard view
 * Pipeline stats, revenue chart, top frameworks, recent quotes.
 */
'use client'

import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api-client'
import { formatINR, formatNumberIN, formatRelativeTime } from '@/lib/currency'
import { StatusBadge } from '@/components/isecurify/Atoms'
import { TopBar } from '@/components/isecurify/Shell'
import { useNavStore } from '@/store'
import {
  FileText,
  TrendingUp,
  Users,
  Wallet,
  ArrowUpRight,
  BarChart3,
  Plus,
  Loader2,
} from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts'
import type { DashboardStats } from '@/types'

const PIE_COLORS = ['#0F766E', '#0D9488', '#14B8A6', '#5EEAD4', '#F59E0B', '#F97316', '#EF4444', '#8B5CF6']

export function DashboardView() {
  const { navigate } = useNavStore()
  const { data: stats, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardStats>('/dashboard'),
  })

  const totalQuotes = stats?.totalQuotes ?? 0
  const quotesByStatus = stats?.quotesByStatus ?? {}
  const pipelineValue = stats?.pipelineValueInr ?? 0
  const activeClients = stats?.activeClients ?? 0
  const totalClients = stats?.totalClients ?? 0
  const avgValue = stats?.avgQuoteValueInr ?? 0
  const topFrameworks = stats?.topFrameworks ?? []
  const monthlyRevenue = stats?.monthlyRevenue ?? []
  const recentQuotes = stats?.recentQuotes ?? []

  const statusPieData = Object.entries(quotesByStatus).map(([name, value]) => ({
    name: name.replace(/_/g, ' '),
    value,
  }))

  return (
    <>
      <TopBar
        title="Dashboard"
        subtitle="GRC pricing pipeline overview"
        action={
          <button
            onClick={() => navigate('quote-builder')}
            className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 transition-colors"
          >
            <Plus className="h-4 w-4" />
            New Quote
          </button>
        }
      />

      <div className="p-4 md:p-8 space-y-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-6 w-6 animate-spin text-teal-600" />
          </div>
        ) : (
          <>
            {/* KPI cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <KpiCard
                icon={<FileText className="h-5 w-5" />}
                label="Total Quotes"
                value={formatNumberIN(totalQuotes)}
                accent="teal"
              />
              <KpiCard
                icon={<Wallet className="h-5 w-5" />}
                label="Pipeline Value"
                value={formatINR(pipelineValue)}
                accent="amber"
              />
              <KpiCard
                icon={<Users className="h-5 w-5" />}
                label="Active Clients"
                value={`${activeClients} / ${totalClients}`}
                accent="violet"
              />
              <KpiCard
                icon={<TrendingUp className="h-5 w-5" />}
                label="Avg. Quote Value"
                value={formatINR(avgValue)}
                accent="emerald"
              />
            </div>

            {/* Charts row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Monthly revenue */}
              <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">Approved Revenue Trend</h3>
                    <p className="text-xs text-slate-500">Last 6 months • INR (Lakh format)</p>
                  </div>
                  <BarChart3 className="h-4 w-4 text-slate-400" />
                </div>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={monthlyRevenue}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#64748b' }} axisLine={false} tickLine={false} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(v) => v >= 10000000 ? `${(v / 10000000).toFixed(1)}Cr` : v >= 100000 ? `${(v / 100000).toFixed(1)}L` : `${v / 1000}k`}
                    />
                    <Tooltip
                      formatter={(v: number) => [formatINR(v), 'Revenue']}
                      contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }}
                    />
                    <Bar dataKey="valueInr" fill="#0F766E" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Status distribution */}
              <div className="rounded-xl border border-slate-200 bg-white p-5">
                <h3 className="text-sm font-semibold text-slate-900 mb-1">Quotes by Status</h3>
                <p className="text-xs text-slate-500 mb-4">Pipeline distribution</p>
                {statusPieData.length === 0 ? (
                  <div className="h-[260px] flex items-center justify-center text-sm text-slate-400">
                    No quotes yet
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={260}>
                    <PieChart>
                      <Pie
                        data={statusPieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        innerRadius={40}
                        paddingAngle={2}
                      >
                        {statusPieData.map((_, i) => (
                          <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            {/* Top frameworks + recent quotes */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Top frameworks */}
              <div className="rounded-xl border border-slate-200 bg-white p-5">
                <h3 className="text-sm font-semibold text-slate-900 mb-4">Top Frameworks</h3>
                <div className="space-y-3">
                  {topFrameworks.length === 0 ? (
                    <p className="text-sm text-slate-400 py-6 text-center">No data yet</p>
                  ) : (
                    topFrameworks.map((fw, i) => (
                      <div key={fw.name} className="flex items-center gap-3">
                        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-50 text-xs font-bold text-teal-700">
                          {i + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-900 truncate">{fw.name}</p>
                          <p className="text-xs text-slate-500">{fw.count} quotes • {formatINR(fw.valueInr)}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Recent quotes */}
              <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white">
                <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
                  <h3 className="text-sm font-semibold text-slate-900">Recent Quotes</h3>
                  <button
                    onClick={() => navigate('quotes')}
                    className="inline-flex items-center gap-1 text-xs font-medium text-teal-700 hover:text-teal-800"
                  >
                    View all <ArrowUpRight className="h-3 w-3" />
                  </button>
                </div>
                <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
                  {recentQuotes.length === 0 ? (
                    <p className="text-sm text-slate-400 py-8 text-center">No quotes yet. Create your first quote!</p>
                  ) : (
                    recentQuotes.map((q) => (
                      <button
                        key={q.id}
                        onClick={() => navigate('quotes', { id: q.id })}
                        className="w-full flex items-center justify-between gap-4 px-5 py-3 hover:bg-slate-50 transition-colors text-left"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium text-slate-900 truncate">
                              {q.client?.companyName || 'Unknown client'}
                            </p>
                            <StatusBadge status={q.status} />
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5">
                            {q.framework?.name} • {formatRelativeTime(q.createdAt)}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-sm font-bold text-slate-900">{formatINR(q.totalInr)}</p>
                          <p className="text-[11px] text-slate-500">v{q.version}</p>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  )
}

function KpiCard({ icon, label, value, accent }: {
  icon: React.ReactNode
  label: string
  value: string
  accent: 'teal' | 'amber' | 'violet' | 'emerald'
}) {
  const accents = {
    teal: 'bg-teal-50 text-teal-700',
    amber: 'bg-amber-50 text-amber-700',
    violet: 'bg-violet-50 text-violet-700',
    emerald: 'bg-emerald-50 text-emerald-700',
  }
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 md:p-5">
      <div className="flex items-center justify-between mb-3">
        <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${accents[accent]}`}>
          {icon}
        </span>
      </div>
      <p className="text-xs text-slate-500">{label}</p>
      <p className="text-lg md:text-xl font-bold text-slate-900 mt-0.5 truncate">{value}</p>
    </div>
  )
}
