/**
 * iSecurify — Admin Panel
 * Sections: Frameworks, Tiers, Framework Prices grid, Auditor Fees,
 *           Add-on Services, GRC Tools, DPO/vCISO Packages, FX Rate
 */
'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '@/lib/api-client'
import { TopBar } from '@/components/isecurify/Shell'
import { SectionCard, EmptyState } from '@/components/isecurify/Atoms'
import { formatINR } from '@/lib/currency'
import { FRAMEWORK_CATEGORY_META } from '@/lib/quoteCalculator'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import { useState } from 'react'
import {
  Settings,
  Layers,
  ShieldCheck,
  Banknote,
  Package,
  Wrench,
  Clock,
  TrendingUp,
  Loader2,
  Pencil,
  Check,
  X,
  Plus,
} from 'lucide-react'
import type {
  Framework,
  Tier,
  FrameworkPrice,
  AuditorFee,
  AddonService,
  GrcTool,
  DpoVcisoPackage,
} from '@/types'

type Section =
  | 'frameworks'
  | 'tiers'
  | 'prices'
  | 'auditors'
  | 'addons'
  | 'grc'
  | 'dpo'
  | 'fx'

const SECTIONS: Array<{ id: Section; label: string; icon: React.ReactNode }> = [
  { id: 'frameworks', label: 'Frameworks', icon: <Layers className="h-4 w-4" /> },
  { id: 'tiers', label: 'Tiers', icon: <ShieldCheck className="h-4 w-4" /> },
  { id: 'prices', label: 'Framework Prices', icon: <Banknote className="h-4 w-4" /> },
  { id: 'auditors', label: 'Auditor Fees', icon: <Check className="h-4 w-4" /> },
  { id: 'addons', label: 'Add-on Services', icon: <Package className="h-4 w-4" /> },
  { id: 'grc', label: 'GRC Tools', icon: <Wrench className="h-4 w-4" /> },
  { id: 'dpo', label: 'DPO / vCISO', icon: <Clock className="h-4 w-4" /> },
  { id: 'fx', label: 'FX Rate', icon: <TrendingUp className="h-4 w-4" /> },
]

interface PricingData {
  frameworks: Framework[]
  tiers: Tier[]
  frameworkPrices: FrameworkPrice[]
  auditorFees: AuditorFee[]
  addonServices: AddonService[]
  grcTools: GrcTool[]
  dpoVcisoPackages: DpoVcisoPackage[]
  fxRate: number
}

export function AdminView() {
  const [section, setSection] = useState<Section>('frameworks')

  const { data, isLoading } = useQuery({
    queryKey: ['pricing'],
    queryFn: () => api.get<PricingData>('/pricing'),
  })

  return (
    <>
      <TopBar title="Admin Panel" subtitle="Master pricing data management" />

      <div className="flex flex-col lg:flex-row min-h-[calc(100vh-4rem)]">
        {/* Section tabs */}
        <div className="lg:w-60 border-b lg:border-b-0 lg:border-r border-slate-200 bg-white p-3 lg:p-4">
          <div className="flex lg:flex-col gap-1 overflow-x-auto">
            {SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => setSection(s.id)}
                className={cn(
                  'shrink-0 flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  section === s.id
                    ? 'bg-teal-50 text-teal-800'
                    : 'text-slate-600 hover:bg-slate-100',
                )}
              >
                {s.icon} {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Section content */}
        <div className="flex-1 p-4 md:p-8 min-w-0">
          {isLoading || !data ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-6 w-6 animate-spin text-teal-600" />
            </div>
          ) : (
            <>
              {section === 'frameworks' && <FrameworksSection data={data} />}
              {section === 'tiers' && <TiersSection data={data} />}
              {section === 'prices' && <PricesSection data={data} />}
              {section === 'auditors' && <AuditorsSection data={data} />}
              {section === 'addons' && <AddonsSection data={data} />}
              {section === 'grc' && <GrcSection data={data} />}
              {section === 'dpo' && <DpoSection data={data} />}
              {section === 'fx' && <FxSection rate={data.fxRate} />}
            </>
          )}
        </div>
      </div>
    </>
  )
}

// ─── Frameworks ────────────────────────────────────────────────
function FrameworksSection({ data }: { data: PricingData }) {
  const grouped = data.frameworks.reduce((acc, fw) => {
    (acc[fw.category] ||= []).push(fw)
    return acc
  }, {} as Record<string, Framework[]>)

  return (
    <SectionCard title="Frameworks" description={`${data.frameworks.length} active frameworks, grouped by category`}>
      <div className="space-y-5">
        {Object.entries(grouped).map(([category, fws]) => {
          const meta = FRAMEWORK_CATEGORY_META[category] || { label: category }
          return (
            <div key={category}>
              <h4 className="text-xs font-bold uppercase tracking-wide text-slate-500 mb-2">{meta.label}</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {fws.map((fw) => (
                  <div key={fw.id} className="rounded-lg border border-slate-200 p-3">
                    <p className="text-sm font-medium text-slate-900">{fw.name}</p>
                    <p className="text-xs text-slate-500 line-clamp-2 mt-0.5">{fw.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </SectionCard>
  )
}

// ─── Tiers ─────────────────────────────────────────────────────
function TiersSection({ data }: { data: PricingData }) {
  return (
    <SectionCard title="Tiers" description={`${data.tiers.length} company-size tiers with retainer percentages`}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {data.tiers.map((tier) => (
          <div key={tier.id} className="rounded-lg border border-slate-200 p-4">
            <p className="text-sm font-bold text-slate-900">{tier.name}</p>
            <p className="text-2xl font-bold text-teal-700 mt-1">{tier.retainerPct}%</p>
            <p className="text-xs text-slate-500 mt-0.5">annual retainer</p>
          </div>
        ))}
      </div>
    </SectionCard>
  )
}

// ─── Framework Prices (editable grid) ──────────────────────────
function PricesSection({ data }: { data: PricingData }) {
  return (
    <SectionCard
      title="Framework Price Grid"
      description="Rows = frameworks, columns = tiers. All prices in INR (Lakh format)."
    >
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="border-b border-slate-200">
              <th className="text-left px-3 py-2 font-semibold text-slate-600 sticky left-0 bg-white">Framework</th>
              {data.tiers.map((t) => (
                <th key={t.id} className="text-right px-3 py-2 font-semibold text-slate-600 whitespace-nowrap">
                  {t.name}
                  <span className="block text-[10px] font-normal text-slate-400">({t.retainerPct}% ret.)</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.frameworks.map((fw) => (
              <tr key={fw.id} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="px-3 py-2 font-medium text-slate-900 sticky left-0 bg-white">
                  {fw.name}
                  <span className="block text-[10px] text-slate-400">{FRAMEWORK_CATEGORY_META[fw.category]?.label}</span>
                </td>
                {data.tiers.map((t) => {
                  const price = data.frameworkPrices.find(
                    (p) => p.frameworkId === fw.id && p.tierId === t.id,
                  )
                  return (
                    <td key={t.id} className="text-right px-3 py-2 tabular-nums text-slate-700">
                      {price ? formatINR(price.projectFeeInr) : '—'}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SectionCard>
  )
}

// ─── Auditor Fees ──────────────────────────────────────────────
function AuditorsSection({ data }: { data: PricingData }) {
  const grouped = data.auditorFees.reduce((acc, fee) => {
    (acc[fee.standardName] ||= []).push(fee)
    return acc
  }, {} as Record<string, AuditorFee[]>)

  return (
    <SectionCard title="Auditor Fees" description={`${data.auditorFees.length} certification body fees — pass-through costs`}>
      <div className="space-y-4">
        {Object.entries(grouped).map(([standard, fees]) => (
          <div key={standard} className="rounded-lg border border-slate-200 p-3">
            <p className="text-xs font-bold uppercase tracking-wide text-slate-500 mb-2">{standard}</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {fees.map((fee) => (
                <div key={fee.id} className="flex items-center justify-between rounded bg-slate-50 px-3 py-2">
                  <div>
                    <p className="text-xs font-medium text-slate-700">{fee.accreditationBody}</p>
                    {fee.notes && <p className="text-[10px] text-slate-400">{fee.notes}</p>}
                  </div>
                  <p className="text-sm font-bold text-slate-900">{formatINR(fee.feeInr)}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </SectionCard>
  )
}

// ─── Add-on Services ───────────────────────────────────────────
function AddonsSection({ data }: { data: PricingData }) {
  return (
    <SectionCard title="Add-on Services" description={`${data.addonServices.length} optional bolt-on services`}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {data.addonServices.map((addon) => (
          <div key={addon.id} className="rounded-lg border border-slate-200 p-4 flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-slate-900">{addon.name}</p>
              <p className="text-xs text-slate-500 mt-0.5 line-clamp-2">{addon.description}</p>
              <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-600">
                {addon.category.replace(/_/g, ' ')}
              </span>
            </div>
            <p className="text-sm font-bold text-slate-900 shrink-0">{formatINR(addon.feeInr)}</p>
          </div>
        ))}
      </div>
    </SectionCard>
  )
}

// ─── GRC Tools ─────────────────────────────────────────────────
function GrcSection({ data }: { data: PricingData }) {
  return (
    <SectionCard title="GRC Tools" description={`${data.grcTools.length} annual subscription plans`}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {data.grcTools.map((tool) => (
          <div key={tool.id} className="rounded-lg border border-slate-200 p-4">
            <p className="text-sm font-bold text-slate-900">{tool.planName}</p>
            <p className="text-2xl font-bold text-teal-700 mt-1">{formatINR(tool.feeInrAnnual)}</p>
            <p className="text-xs text-slate-500">/year</p>
            <p className="text-xs text-slate-600 mt-2 line-clamp-2">{tool.description}</p>
            <p className="text-xs text-slate-500 mt-2">
              Up to {tool.maxUsers >= 999999 ? 'unlimited' : tool.maxUsers} users
            </p>
          </div>
        ))}
      </div>
    </SectionCard>
  )
}

// ─── DPO / vCISO ───────────────────────────────────────────────
function DpoSection({ data }: { data: PricingData }) {
  const grouped = data.dpoVcisoPackages.reduce((acc, pkg) => {
    (acc[pkg.serviceType] ||= []).push(pkg)
    return acc
  }, {} as Record<string, DpoVcisoPackage[]>)

  return (
    <SectionCard title="DPO / vCISO Packages" description={`${data.dpoVcisoPackages.length} managed compliance service plans`}>
      <div className="space-y-5">
        {Object.entries(grouped).map(([type, pkgs]) => (
          <div key={type}>
            <h4 className="text-xs font-bold uppercase tracking-wide text-slate-500 mb-2">
              {type === 'DPO_vCISO' ? 'DPO + vCISO Combined' : type}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {pkgs.map((pkg) => (
                <div key={pkg.id} className="rounded-lg border border-slate-200 p-4">
                  <p className="text-sm font-bold text-slate-900">{pkg.name}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{pkg.hoursPerMonth} hours/month</p>
                  <div className="mt-3 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Monthly</span>
                      <span className="font-medium text-slate-900">{formatINR(pkg.feeInrMonthly)}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Annual</span>
                      <span className="font-bold text-teal-700">{formatINR(pkg.feeInrAnnual)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </SectionCard>
  )
}

// ─── FX Rate ───────────────────────────────────────────────────
function FxSection({ rate: currentRate }: { rate: number }) {
  const qc = useQueryClient()
  const [rate, setRate] = useState(currentRate)
  const [editing, setEditing] = useState(false)

  const updateMutation = useMutation({
    mutationFn: (newRate: number) => api.put('/fx-rate', { rate: newRate }),
    onSuccess: () => {
      toast.success('FX rate updated')
      setEditing(false)
      qc.invalidateQueries({ queryKey: ['pricing'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
    },
    onError: (e: Error) => toast.error(e.message),
  })

  return (
    <SectionCard title="FX Rate" description="USD to INR conversion rate — used for USD equivalent on quotes">
      <div className="max-w-md">
        <div className="rounded-lg border border-slate-200 p-5">
          <p className="text-xs text-slate-500 mb-1">Current USD/INR Rate</p>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900">₹{rate}</span>
            <span className="text-sm text-slate-500">per USD</span>
          </div>

          {editing ? (
            <div className="mt-4 space-y-3">
              <input
                type="number"
                value={rate}
                onChange={(e) => setRate(parseFloat(e.target.value) || 0)}
                step="0.01"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
              <div className="flex gap-2">
                <button
                  onClick={() => updateMutation.mutate(rate)}
                  disabled={updateMutation.isPending}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-50"
                >
                  <Check className="h-4 w-4" /> Save
                </button>
                <button
                  onClick={() => { setRate(currentRate); setEditing(false) }}
                  className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setEditing(true)}
              className="mt-4 inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <Pencil className="h-3.5 w-3.5" /> Update Rate
            </button>
          )}
        </div>

        <div className="mt-3 rounded-lg bg-amber-50 border border-amber-200 p-3">
          <p className="text-xs text-amber-800">
            <TrendingUp className="inline h-3.5 w-3.5 mr-1" />
            This rate is snapshotted at quote creation time. Existing quotes retain their original rate.
          </p>
        </div>
      </div>
    </SectionCard>
  )
}
