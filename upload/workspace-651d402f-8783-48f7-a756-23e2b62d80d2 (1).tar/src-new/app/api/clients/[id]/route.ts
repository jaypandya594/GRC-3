/**
 * /api/clients/[id]
 * GET   — get a single client with quotes
 * PATCH — update client (e.g., change deal stage)
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TENANT_ID, CREATED_BY_ID } from '@/lib/server/pricingEngine'

export const dynamic = 'force-dynamic'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const client = await db.client.findUnique({
      where: { id },
      include: {
        quotes: {
          include: {
            framework: true,
            tier: true,
          },
          orderBy: { createdAt: 'desc' },
        },
        createdBy: { select: { name: true, email: true } },
      },
    })

    if (!client) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 })
    }

    const formatted = {
      ...client,
      contacts: client.contactsJson ? JSON.parse(client.contactsJson) : [],
    }

    return NextResponse.json({ data: formatted })
  } catch (err) {
    console.error('[GET /api/clients/[id]] error:', err)
    return NextResponse.json({ error: 'Failed to load client' }, { status: 500 })
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const body = await req.json()

    const existing = await db.client.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 })
    }

    const updated = await db.client.update({
      where: { id },
      data: {
        companyName: body.companyName ?? existing.companyName,
        sector: body.sector ?? existing.sector,
        companySize: body.companySize ?? existing.companySize,
        dealStage: body.dealStage ?? existing.dealStage,
        notes: body.notes ?? existing.notes,
        contactsJson: body.contacts ? JSON.stringify(body.contacts) : existing.contactsJson,
      },
    })

    await db.auditLog.create({
      data: {
        tenantId: TENANT_ID,
        userId: CREATED_BY_ID,
        action: 'client.updated',
        entity: 'client',
        entityId: id,
        oldValue: JSON.stringify({ dealStage: existing.dealStage }),
        newValue: JSON.stringify({ dealStage: updated.dealStage }),
      },
    })

    return NextResponse.json({ data: updated })
  } catch (err) {
    console.error('[PATCH /api/clients/[id]] error:', err)
    return NextResponse.json({ error: 'Failed to update client' }, { status: 500 })
  }
}
