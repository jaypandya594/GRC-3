/**
 * /api/clients
 * GET  — list all clients
 * POST — create a new client
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TENANT_ID, CREATED_BY_ID } from '@/lib/server/pricingEngine'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const stage = req.nextUrl.searchParams.get('stage')
    const clients = await db.client.findMany({
      where: {
        tenantId: TENANT_ID,
        ...(stage && stage !== 'all' ? { dealStage: stage } : {}),
      },
      include: {
        _count: { select: { quotes: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    const formatted = clients.map((c) => ({
      ...c,
      contacts: c.contactsJson ? JSON.parse(c.contactsJson) : [],
      quoteCount: c._count.quotes,
      _count: undefined,
    }))

    return NextResponse.json({ data: formatted })
  } catch (err) {
    console.error('[GET /api/clients] error:', err)
    return NextResponse.json({ error: 'Failed to load clients' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { companyName, sector, companySize, dealStage, contacts, notes } = body

    if (!companyName) {
      return NextResponse.json({ error: 'Company name is required' }, { status: 400 })
    }

    const client = await db.client.create({
      data: {
        tenantId: TENANT_ID,
        companyName,
        sector: sector || null,
        companySize: companySize || 'Mid-size',
        dealStage: dealStage || 'prospect',
        contactsJson: contacts ? JSON.stringify(contacts) : null,
        notes: notes || null,
        createdById: CREATED_BY_ID,
      },
    })

    await db.auditLog.create({
      data: {
        tenantId: TENANT_ID,
        userId: CREATED_BY_ID,
        action: 'client.created',
        entity: 'client',
        entityId: client.id,
        newValue: JSON.stringify({ companyName }),
      },
    })

    return NextResponse.json({ data: client }, { status: 201 })
  } catch (err) {
    console.error('[POST /api/clients] error:', err)
    return NextResponse.json({ error: 'Failed to create client' }, { status: 500 })
  }
}
