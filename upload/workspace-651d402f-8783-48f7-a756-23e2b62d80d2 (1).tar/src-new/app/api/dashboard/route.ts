/**
 * GET /api/dashboard — aggregated stats for the dashboard
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TENANT_ID } from '@/lib/server/pricingEngine'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const [quotes, clients, fxRate] = await Promise.all([
      db.quote.findMany({
        where: { tenantId: TENANT_ID },
        include: {
          client: true,
          framework: true,
          tier: true,
          createdBy: { select: { name: true, email: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      db.client.findMany({ where: { tenantId: TENANT_ID } }),
      db.fxRate.findFirst(),
    ])

    const quotesByStatus: Record<string, number> = {}
    let pipelineValue = 0
    let wonValue = 0
    const frameworkAgg: Record<string, { name: string; count: number; valueInr: number }> = {}

    for (const q of quotes) {
      quotesByStatus[q.status] = (quotesByStatus[q.status] || 0) + 1
      // Pipeline = quotes not yet won/lost/rejected/expired
      if (!['REJECTED', 'EXPIRED'].includes(q.status)) {
        pipelineValue += q.totalInr
      }
      if (q.status === 'SENT' || q.status === 'VIEWED' || q.client?.dealStage === 'won') {
        // approximate
      }
      if (q.client?.dealStage === 'won') {
        wonValue += q.totalInr
      }

      const fwName = q.framework?.name || 'Unknown'
      if (!frameworkAgg[fwName]) {
        frameworkAgg[fwName] = { name: fwName, count: 0, valueInr: 0 }
      }
      frameworkAgg[fwName].count += 1
      frameworkAgg[fwName].valueInr += q.totalInr
    }

    const topFrameworks = Object.values(frameworkAgg)
      .sort((a, b) => b.count - a.count)
      .slice(0, 6)

    const avgQuoteValue = quotes.length > 0
      ? Math.round(quotes.reduce((s, q) => s + q.totalInr, 0) / quotes.length)
      : 0

    // Monthly revenue (last 6 months) — sum of approved/sent quotes by month
    const now = new Date()
    const monthlyRevenue: Array<{ month: string; valueInr: number }> = []
    for (let i = 5; i >= 0; i--) {
      const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0, 23, 59, 59)
      const monthQuotes = quotes.filter((q) => {
        const created = new Date(q.createdAt)
        return created >= monthDate && created <= monthEnd &&
          ['APPROVED', 'SENT', 'VIEWED'].includes(q.status)
      })
      monthlyRevenue.push({
        month: monthDate.toLocaleString('en-IN', { month: 'short' }),
        valueInr: monthQuotes.reduce((s, q) => s + q.totalInr, 0),
      })
    }

    const recentQuotes = quotes.slice(0, 8)

    return NextResponse.json({
      data: {
        totalQuotes: quotes.length,
        quotesByStatus,
        pipelineValueInr: pipelineValue,
        wonValueInr: wonValue,
        activeClients: clients.filter((c) => !['won', 'lost'].includes(c.dealStage)).length,
        totalClients: clients.length,
        avgQuoteValueInr: avgQuoteValue,
        topFrameworks,
        recentQuotes,
        monthlyRevenue,
        fxRate: fxRate?.rate ?? 83,
      },
    })
  } catch (err) {
    console.error('[GET /api/dashboard] error:', err)
    return NextResponse.json({ error: 'Failed to load dashboard stats' }, { status: 500 })
  }
}
