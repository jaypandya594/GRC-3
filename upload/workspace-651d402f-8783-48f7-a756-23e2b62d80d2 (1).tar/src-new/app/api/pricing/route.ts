/**
 * GET /api/pricing — returns all active master pricing data
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const [
      frameworks,
      tiers,
      frameworkPrices,
      auditorFees,
      addonServices,
      grcTools,
      dpoVcisoPackages,
      fxRate,
    ] = await Promise.all([
      db.framework.findMany({
        where: { isActive: true },
        orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
      }),
      db.tier.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      }),
      db.frameworkPrice.findMany(),
      db.auditorFee.findMany({
        where: { isActive: true },
        orderBy: [{ standardName: 'asc' }, { feeInr: 'asc' }],
      }),
      db.addonService.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
      }),
      db.grcTool.findMany({
        where: { isActive: true },
        orderBy: { feeInrAnnual: 'asc' },
      }),
      db.dpoVcisoPackage.findMany({
        where: { isActive: true },
        orderBy: [{ serviceType: 'asc' }, { feeInrMonthly: 'asc' }],
      }),
      db.fxRate.findFirst(),
    ])

    return NextResponse.json({
      data: {
        frameworks,
        tiers,
        frameworkPrices,
        auditorFees,
        addonServices,
        grcTools,
        dpoVcisoPackages,
        fxRate: fxRate?.rate ?? 83,
      },
    })
  } catch (err) {
    console.error('[GET /api/pricing] error:', err)
    return NextResponse.json(
      { error: 'Failed to load pricing data' },
      { status: 500 },
    )
  }
}
