/**
 * /api/quotes
 * GET    — list quotes (supports ?status= filter)
 * POST   — create a new quote (draft or submitted)
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { computeQuote, TENANT_ID, CREATED_BY_ID } from '@/lib/server/pricingEngine'
import type { QuoteBuilderSelection } from '@/types'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get('status')
    const clientId = req.nextUrl.searchParams.get('clientId')

    const quotes = await db.quote.findMany({
      where: {
        tenantId: TENANT_ID,
        ...(status && status !== 'all' ? { status } : {}),
        ...(clientId ? { clientId } : {}),
      },
      include: {
        client: true,
        framework: true,
        tier: true,
        createdBy: { select: { name: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: quotes })
  } catch (err) {
    console.error('[GET /api/quotes] error:', err)
    return NextResponse.json({ error: 'Failed to load quotes' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      selection: QuoteBuilderSelection
      submit?: boolean
    }
    const { selection, submit } = body

    if (!selection.clientId) {
      return NextResponse.json({ error: 'Client is required' }, { status: 400 })
    }
    if (!selection.frameworkId || !selection.tierId) {
      return NextResponse.json(
        { error: 'Framework and tier are required' },
        { status: 400 },
      )
    }

    const computed = await computeQuote(selection)
    if (!computed) {
      return NextResponse.json(
        { error: 'Could not compute quote — invalid framework/tier' },
        { status: 400 },
      )
    }

    const validUntil = new Date()
    validUntil.setDate(validUntil.getDate() + (selection.validUntilDays || 30))

    const status = submit ? 'PENDING_REVIEW' : 'DRAFT'

    const quote = await db.quote.create({
      data: {
        tenantId: TENANT_ID,
        clientId: selection.clientId,
        version: 1,
        status,
        frameworkId: computed.frameworkId,
        tierId: computed.tierId,
        subtotalInr: computed.subtotalInr,
        discountInr: computed.discountInr,
        discountReason: selection.discountReason || null,
        gstAmountInr: computed.gstAmountInr,
        totalInr: computed.totalInr,
        totalUsd: computed.totalUsd,
        usdInrRateSnapshot: computed.usdInrRateSnapshot,
        gstRateSnapshot: computed.gstRateSnapshot,
        includeRetainer: computed.includeRetainer,
        retainerAmountInr: computed.retainerAmountInr,
        internalHours: computed.internalHours,
        internalHourlyRate: computed.internalHourlyRate,
        validUntil,
        notes: selection.notes || null,
        createdById: CREATED_BY_ID,
        lineItems: {
          create: computed.lines,
        },
      },
      include: {
        client: true,
        framework: true,
        tier: true,
        lineItems: true,
      },
    })

    // Log the approval action
    if (submit) {
      await db.quoteApproval.create({
        data: {
          quoteId: quote.id,
          actorId: CREATED_BY_ID,
          actorRole: 'sales_executive',
          action: 'submitted',
          amountBefore: 0,
          amountAfter: computed.totalInr,
        },
      })
    }

    // Write to audit log
    await db.auditLog.create({
      data: {
        tenantId: TENANT_ID,
        userId: CREATED_BY_ID,
        action: submit ? 'quote.submitted' : 'quote.created',
        entity: 'quote',
        entityId: quote.id,
        newValue: JSON.stringify({ status, totalInr: computed.totalInr }),
      },
    })

    return NextResponse.json({ data: quote }, { status: 201 })
  } catch (err) {
    console.error('[POST /api/quotes] error:', err)
    return NextResponse.json({ error: 'Failed to create quote' }, { status: 500 })
  }
}
