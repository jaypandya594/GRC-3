/**
 * /api/quotes/[id]
 * GET    — get a single quote with line items + approvals
 * PUT    — update a draft quote (recompute totals)
 * DELETE — soft delete (set status REJECTED)
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { computeQuote, TENANT_ID, CREATED_BY_ID } from '@/lib/server/pricingEngine'
import type { QuoteBuilderSelection } from '@/types'

export const dynamic = 'force-dynamic'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const quote = await db.quote.findUnique({
      where: { id },
      include: {
        client: true,
        framework: true,
        tier: true,
        lineItems: { orderBy: { sortOrder: 'asc' } },
        approvals: {
          include: { actor: { select: { name: true, email: true } } },
          orderBy: { createdAt: 'asc' },
        },
        createdBy: { select: { name: true, email: true } },
      },
    })

    if (!quote) {
      return NextResponse.json({ error: 'Quote not found' }, { status: 404 })
    }

    return NextResponse.json({ data: quote })
  } catch (err) {
    console.error('[GET /api/quotes/[id]] error:', err)
    return NextResponse.json({ error: 'Failed to load quote' }, { status: 500 })
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const body = (await req.json()) as {
      selection: QuoteBuilderSelection
    }

    const existing = await db.quote.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Quote not found' }, { status: 404 })
    }
    if (existing.status !== 'DRAFT') {
      return NextResponse.json(
        { error: 'Only draft quotes can be edited' },
        { status: 400 },
      )
    }

    const computed = await computeQuote(body.selection)
    if (!computed) {
      return NextResponse.json({ error: 'Invalid selection' }, { status: 400 })
    }

    // Delete old line items and recreate
    await db.quoteLineItem.deleteMany({ where: { quoteId: id } })

    const validUntil = new Date()
    validUntil.setDate(validUntil.getDate() + (body.selection.validUntilDays || 30))

    const updated = await db.quote.update({
      where: { id },
      data: {
        clientId: body.selection.clientId || existing.clientId,
        frameworkId: computed.frameworkId,
        tierId: computed.tierId,
        subtotalInr: computed.subtotalInr,
        discountInr: computed.discountInr,
        discountReason: body.selection.discountReason || null,
        gstAmountInr: computed.gstAmountInr,
        totalInr: computed.totalInr,
        totalUsd: computed.totalUsd,
        usdInrRateSnapshot: computed.usdInrRateSnapshot,
        gstRateSnapshot: computed.gstRateSnapshot,
        includeRetainer: computed.includeRetainer,
        retainerAmountInr: computed.retainerAmountInr,
        internalHours: computed.internalHours,
        internalHourlyRate: computed.internalHourlyRate,
        validUntil,
        notes: body.selection.notes || null,
        lineItems: { create: computed.lines },
      },
      include: {
        client: true,
        framework: true,
        tier: true,
        lineItems: { orderBy: { sortOrder: 'asc' } },
      },
    })

    await db.auditLog.create({
      data: {
        tenantId: TENANT_ID,
        userId: CREATED_BY_ID,
        action: 'quote.updated',
        entity: 'quote',
        entityId: id,
        oldValue: JSON.stringify({ totalInr: existing.totalInr }),
        newValue: JSON.stringify({ totalInr: computed.totalInr }),
      },
    })

    return NextResponse.json({ data: updated })
  } catch (err) {
    console.error('[PUT /api/quotes/[id]] error:', err)
    return NextResponse.json({ error: 'Failed to update quote' }, { status: 500 })
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const existing = await db.quote.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Quote not found' }, { status: 404 })
    }

    // Soft delete: set status to REJECTED
    const updated = await db.quote.update({
      where: { id },
      data: { status: 'REJECTED' },
    })

    await db.auditLog.create({
      data: {
        tenantId: TENANT_ID,
        userId: CREATED_BY_ID,
        action: 'quote.deleted',
        entity: 'quote',
        entityId: id,
        oldValue: JSON.stringify({ status: existing.status }),
        newValue: JSON.stringify({ status: 'REJECTED' }),
      },
    })

    return NextResponse.json({ data: updated })
  } catch (err) {
    console.error('[DELETE /api/quotes/[id]] error:', err)
    return NextResponse.json({ error: 'Failed to delete quote' }, { status: 500 })
  }
}
