/**
 * /api/quotes/[id]/action
 * POST — perform an approval workflow action
 *   body: { action: 'submit'|'approve'|'reject'|'override'|'recall'|'send', comment?, newDiscountInr? }
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TENANT_ID, CREATED_BY_ID } from '@/lib/server/pricingEngine'

export const dynamic = 'force-dynamic'

const TRANSITIONS: Record<string, Record<string, { next: string; roles: string[] }>> = {
  DRAFT: {
    submit: { next: 'PENDING_REVIEW', roles: ['sales_executive', 'sales_manager', 'tenant_admin', 'super_admin', 'finance'] },
  },
  PENDING_REVIEW: {
    approve: { next: 'PENDING_FINANCE', roles: ['sales_manager', 'tenant_admin', 'super_admin', 'finance'] },
    reject: { next: 'DRAFT', roles: ['sales_manager', 'tenant_admin', 'super_admin'] },
    recall: { next: 'DRAFT', roles: ['sales_executive', 'sales_manager', 'super_admin'] },
  },
  PENDING_FINANCE: {
    approve: { next: 'APPROVED', roles: ['finance', 'tenant_admin', 'super_admin'] },
    reject: { next: 'DRAFT', roles: ['finance', 'tenant_admin', 'super_admin'] },
    override: { next: 'APPROVED', roles: ['finance', 'super_admin'] },
  },
  APPROVED: {
    send: { next: 'SENT', roles: ['sales_manager', 'tenant_admin', 'super_admin'] },
    recall: { next: 'DRAFT', roles: ['sales_manager', 'tenant_admin', 'super_admin'] },
  },
  SENT: {
    recall: { next: 'APPROVED', roles: ['sales_manager', 'tenant_admin', 'super_admin'] },
  },
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const body = (await req.json()) as {
      action: string
      comment?: string
      newDiscountInr?: number
      discountReason?: string
    }

    const quote = await db.quote.findUnique({ where: { id } })
    if (!quote) {
      return NextResponse.json({ error: 'Quote not found' }, { status: 404 })
    }

    const stateActions = TRANSITIONS[quote.status]
    const transition = stateActions?.[body.action]
    if (!transition) {
      return NextResponse.json(
        { error: `Action "${body.action}" not allowed in status ${quote.status}` },
        { status: 400 },
      )
    }

    // For demo: we accept all roles (single-user mode). In production, check role.

    let newTotal = quote.totalInr
    let newDiscount = quote.discountInr
    let approvedById = quote.approvedById

    // Finance override: update discount then recompute total
    if (body.action === 'override' && body.newDiscountInr !== undefined) {
      newDiscount = Math.max(0, body.newDiscountInr)
      const subtotalAfterDiscount = Math.max(0, quote.subtotalInr - newDiscount)
      const gstAmount = Math.round(subtotalAfterDiscount * (quote.gstRateSnapshot / 100))
      newTotal = subtotalAfterDiscount + gstAmount
      approvedById = CREATED_BY_ID
    }

    if (body.action === 'approve' && quote.status === 'PENDING_FINANCE') {
      approvedById = CREATED_BY_ID
    }

    const sentAt = body.action === 'send' ? new Date() : quote.sentAt

    const updated = await db.quote.update({
      where: { id },
      data: {
        status: transition.next,
        discountInr: newDiscount,
        discountReason: body.discountReason || quote.discountReason,
        totalInr: newTotal,
        gstAmountInr: Math.round(
          Math.max(0, quote.subtotalInr - newDiscount) * (quote.gstRateSnapshot / 100),
        ),
        approvedById,
        sentAt,
      },
      include: {
        client: true,
        framework: true,
        tier: true,
        lineItems: { orderBy: { sortOrder: 'asc' } },
      },
    })

    // Log the approval action
    await db.quoteApproval.create({
      data: {
        quoteId: id,
        actorId: CREATED_BY_ID,
        actorRole: 'super_admin',
        action: body.action,
        comment: body.comment || null,
        amountBefore: quote.totalInr,
        amountAfter: newTotal,
      },
    })

    await db.auditLog.create({
      data: {
        tenantId: TENANT_ID,
        userId: CREATED_BY_ID,
        action: `quote.${body.action}`,
        entity: 'quote',
        entityId: id,
        oldValue: JSON.stringify({ status: quote.status, totalInr: quote.totalInr }),
        newValue: JSON.stringify({ status: transition.next, totalInr: newTotal }),
      },
    })

    return NextResponse.json({ data: updated })
  } catch (err) {
    console.error('[POST /api/quotes/[id]/action] error:', err)
    return NextResponse.json({ error: 'Failed to perform action' }, { status: 500 })
  }
}
