'use client'

import { useNavStore } from '@/store'
import { Sidebar, MobileNav } from '@/components/isecurify/Shell'
import { DashboardView } from '@/components/isecurify/DashboardView'
import { QuoteBuilderView } from '@/components/isecurify/QuoteBuilderView'
import { QuotesListView, QuoteDetailView } from '@/components/isecurify/QuotesViews'
import { ClientsView } from '@/components/isecurify/ClientsView'
import { AdminView } from '@/components/isecurify/AdminView'

export default function Home() {
  const { view, params } = useNavStore()

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 min-w-0 flex flex-col pb-16 md:pb-0">
          {view === 'dashboard' && <DashboardView />}
          {view === 'quote-builder' && <QuoteBuilderView />}
          {view === 'quotes' && (params.id ? (
            <QuoteDetailView quoteId={params.id} />
          ) : (
            <QuotesListView />
          ))}
          {view === 'clients' && <ClientsView />}
          {view === 'admin' && <AdminView />}
        </main>
      </div>
      <MobileNav />
    </div>
  )
}
