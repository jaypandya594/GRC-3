import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "sonner";
import { QueryProvider } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "iSecurify — GRC Pricing Platform",
  description: "Governance, Risk & Compliance pricing, quoting, and proposal management for Indian compliance consulting firms.",
  keywords: ["iSecurify", "GRC", "compliance", "ISO 27001", "SOC 2", "quoting", "pricing"],
  authors: [{ name: "iSecurify" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-slate-50 text-foreground`}
      >
        <QueryProvider>
          {children}
          <Toaster />
          <SonnerToaster position="top-right" richColors closeButton />
        </QueryProvider>
      </body>
    </html>
  );
}
