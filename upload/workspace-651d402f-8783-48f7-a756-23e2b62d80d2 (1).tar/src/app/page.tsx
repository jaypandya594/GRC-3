'use client'

import { Sidebar, MobileNav } from '@/components/isecurify/Shell'
import { DashboardView } from '@/components/isecurify/DashboardView'
import { QuotesListView, QuoteDetailView } from '@/components/isecurify/QuotesViews'
import { QuoteBuilderView } from '@/components/isecurify/QuoteBuilderView'
import { ClientsView } from '@/components/isecurify/ClientsView'
import { AdminView } from '@/components/isecurify/AdminView'
import { useNavStore } from '@/store'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useState } from 'react'

function ViewRouter() {
  const { view, params } = useNavStore()

  switch (view) {
    case 'dashboard':
      return <DashboardView />
    case 'quotes':
      return params.id ? <QuoteDetailView quoteId={params.id} /> : <QuotesListView />
    case 'quote-builder':
      return <QuoteBuilderView />
    case 'clients':
      return <ClientsView />
    case 'admin':
      return <AdminView />
    default:
      return <DashboardView />
  }
}

export default function Home() {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 30_000,
        retry: 1,
      },
    },
  }))

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex h-screen overflow-hidden bg-slate-50">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
            <ViewRouter />
          </main>
        </div>
        <MobileNav />
      </div>
    </QueryClientProvider>
  )
}