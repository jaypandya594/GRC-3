/**
 * iSecurify — App Shell
 * Sidebar navigation + top bar. This is the persistent layout for the single-page app.
 */
'use client'

import { useNavStore } from '@/store'
import { cn } from '@/lib/utils'
import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api-client'
import {
  LayoutDashboard,
  FilePlus2,
  FileText,
  Users,
  Settings,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'quote-builder', label: 'Quote Builder', icon: FilePlus2 },
  { id: 'quotes', label: 'Quotes', icon: FileText },
  { id: 'clients', label: 'Clients', icon: Users },
  { id: 'admin', label: 'Admin Panel', icon: Settings },
]

export function Sidebar() {
  const { view, navigate } = useNavStore()
  const { data: fxData } = useQuery({
    queryKey: ['fx-rate-sidebar'],
    queryFn: () => api.get<{ rate: number }>('/admin/fx-rate'),
    staleTime: 60_000,
  })
  const fxRate = fxData?.rate ?? 84.5

  return (
    <aside className="hidden md:flex w-64 flex-col border-r border-slate-200 bg-white shrink-0">
      <div className="flex items-center gap-2.5 px-5 h-16 border-b border-slate-200">
        <img src="/logo-small.png" alt="iSecurify" className="h-8 w-8 object-contain" />
        <div className="flex flex-col leading-tight">
          <span className="text-sm font-bold text-slate-900">iSecurify</span>
          <span className="text-[11px] text-slate-500">GRC Pricing Platform</span>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon
          const active = view === item.id
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                active
                  ? 'bg-brand-50 text-brand-800'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {item.label}
            </button>
          )
        })}
      </nav>

      <div className="px-3 py-4 border-t border-slate-200">
        <div className="rounded-lg bg-gradient-to-br from-brand-700 via-brand-800 to-brand-teal-700 p-4 text-white">
          <div className="flex items-center gap-2 mb-1.5">
            <TrendingUp className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase tracking-wide">Live Rate</span>
          </div>
          <p className="text-lg font-bold">USD/INR {fxRate.toFixed(2)}</p>
          <p className="text-[11px] text-brand-100 mt-0.5">GST 18% • Indian Lakh format</p>
        </div>
      </div>
    </aside>
  )
}

export function MobileNav() {
  const { view, navigate } = useNavStore()
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 bg-white border-t border-slate-200 grid grid-cols-5">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon
        const active = view === item.id
        return (
          <button
            key={item.id}
            onClick={() => navigate(item.id)}
            className={cn(
              'flex flex-col items-center justify-center gap-0.5 py-2.5 text-[10px] font-medium',
              active ? 'text-brand-700' : 'text-slate-500',
            )}
          >
            <Icon className="h-5 w-5" />
            {item.label.split(' ')[0]}
          </button>
        )
      })}
    </nav>
  )
}

export function TopBar({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-4 px-4 md:px-8 h-16 border-b border-slate-200 bg-white/80 backdrop-blur">
      <div className="min-w-0">
        <h1 className="text-lg md:text-xl font-bold text-slate-900 truncate">{title}</h1>
        {subtitle && <p className="text-xs md:text-sm text-slate-500 truncate">{subtitle}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </header>
  )
}
